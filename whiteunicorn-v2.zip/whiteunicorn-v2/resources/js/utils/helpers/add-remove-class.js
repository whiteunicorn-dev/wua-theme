export function addClass($el, classnames) {
    return $el.addClass(classnames);
}
export function removeClass($el, classnames) {
    return $el.removeClass(classnames);
}