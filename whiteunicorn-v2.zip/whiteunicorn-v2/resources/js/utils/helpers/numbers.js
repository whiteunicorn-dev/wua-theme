//-- Parse Int Shortcut --//
export function pI(int) {
    return parseInt(int);
}
//-- Parse Float Shortcut --//
export function pF(int) {
    return parseFloat(int);
}