<?php
/**
 * Template Name: Home Page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WhiteUnicorn
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main home-pg">


		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
