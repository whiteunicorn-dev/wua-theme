<?php
/**
 * Template Name: Landing Page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WhiteUnicorn
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main p-r">
			
			
			
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
